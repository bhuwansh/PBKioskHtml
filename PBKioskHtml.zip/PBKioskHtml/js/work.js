﻿function Initialize() {
    //Device initialize
      Reveal.slide(0);


  
            setTimeout(2000);
            document.getElementById("Network_Status").innerHTML = "Connected";
            document.getElementById("Printer_Status").innerHTML = "Connected";
            document.getElementById("Power_Status").innerHTML = "100%";
       
}






function getValue() {
    

            Reveal.slide(1);
            setTimeout(PassbookInserted, 3000);
         
       
}

function PassbookInserted()
{

    Reveal.slide(2);
    setTimeout(Waiting, 3000);


}


function Waiting()
{
    Reveal.slide(3);
    setTimeout(Passbookprinted, 3000);
   
}


function Passbookprinted()
{
    Reveal.slide(0);
    
   

}

