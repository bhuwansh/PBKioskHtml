﻿function Initialize() {
    //Device initialize
    //  Reveal.slide(0);

    var settings =
   {
       "async": true,
       "crossDomain": true,
       "url": "http://127.0.0.1:1234/api/websites/0/0/0",
       "method": "GET",
       "headers":
       {
           "Cache-Control": "no-cache",
           "Postman-Token": "2a8f244a-0da0-462b-8148-ffcc4b3dadcd"
       }
   }

    $.ajax(settings).done(function (response) {
        //- alert(response);
        //-  document.getElementById('lblNoteDetails').innerHTML = response;
        if (response == "true") {
            debugger;
            setTimeout(2000);
            document.getElementById("Network_Status").innerHTML = "Connected";
            document.getElementById("Printer_Status").innerHTML = "Connected";
            document.getElementById("Power_Status").innerHTML = "100%";
        }
        else {


        }

    });
}






function getValue() {
     debugger;
    var settings =
	{
	    "async": true,
	    "crossDomain": true,
	    "url": "http://127.0.0.1:1234/api/websites/6/0/0",
	    "method": "GET",
	    "headers":
        {
            "Cache-Control": "no-cache",
            "Postman-Token": "2a8f244a-0da0-462b-8148-ffcc4b3dadcd"
        }
	}

    $.ajax(settings).done(function (response) {
        //- alert(response);
        //-  document.getElementById('lblNoteDetails').innerHTML = response;
        if (response == "done") {
            debugger;
            Reveal.slide(1);
            setTimeout(PassbookInserted, 3000);
         
        }

    });
}

function PassbookInserted()
{

    Reveal.slide(2);
    setTimeout(Waiting, 3000);


}


function Waiting()
{
    Reveal.slide(3);
    setTimeout(Passbookprinted, 3000);
   
}


function Passbookprinted()
{
    Reveal.slide(0);
    
   

}

